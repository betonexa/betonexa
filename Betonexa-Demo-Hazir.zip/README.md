# Betonexa Demo

Bu klasör doğrudan GitHub'a yüklenip Vercel'de yayınlanabilir.

## Dosyalar
- index.html
- style.css
- app.js
- manifest.json
- vercel.json

## Vercel
1. GitHub'da yeni bir depo açın.
2. Bu klasördeki tüm dosyaları depoya yükleyin.
3. Vercel > Add New > Project bölümünde depoyu seçin.
4. Framework Preset: Other
5. Build Command: boş bırakın
6. Output Directory: boş bırakın
7. Deploy'a basın.

Not: Bu sürüm demodur. Kayıtlar tarayıcının localStorage alanında saklanır; farklı cihazlar arasında ortak veritabanı yoktur.
