const USERS = ["Özlem Gülbay","Cem Ekici","Ali Oğuz"];
const PLANTS = ["Işıkkent","Torbalı","Gaziemir","Özbek","Çeşme","Çiğli","Koyundere","Aliağa","Zeytindağ","Akhisar","Aydın","Tekirdağ","Kıraç","Çorlu"];
const PUMPS = ["Pompasız","38'lik","42'lik","47'lik","52'lik","56'lık"];
const CONFLICT_PUMPS = ["47'lik","52'lik","56'lık"];

const seed = [
 {id:crypto.randomUUID(),date:new Date().toISOString().slice(0,10),time:"09:00",plant:"Işıkkent",company:"Önerge",site:"Bornova Konut Projesi",className:"C30/37",amount:80,pump:"47'lik",contact:"Mehmet Yılmaz",phone:"0532 000 00 01",slump:"S3",additive:"Katkısız",gross:false,note:"1. etap temel",createdBy:"Özlem Gülbay"},
 {id:crypto.randomUUID(),date:new Date().toISOString().slice(0,10),time:"13:30",plant:"Gaziemir",company:"Ege Yapı",site:"Menderes Fabrika",className:"C35/45",amount:55,pump:"42'lik",contact:"Ayşe Demir",phone:"0533 000 00 02",slump:"S4",additive:"Standart",gross:true,note:"",createdBy:"Cem Ekici"}
];

const state = {
 user: localStorage.getItem("betonexa_user") || "",
 shipments: JSON.parse(localStorage.getItem("betonexa_shipments") || "null") || seed,
 editingId: null,
 filters:{q:"",date:"",plant:"",pump:""}
};

function save(){localStorage.setItem("betonexa_shipments",JSON.stringify(state.shipments))}
function esc(v=""){return String(v).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
function fmtDate(v){if(!v)return "";return new Intl.DateTimeFormat("tr-TR",{day:"2-digit",month:"2-digit",year:"numeric"}).format(new Date(v+"T00:00:00"))}
function toast(msg){const el=document.createElement("div");el.className="toast";el.textContent=msg;document.body.appendChild(el);setTimeout(()=>el.remove(),2200)}

function isConflict(item){
 return state.shipments.some(x=>x.id!==item.id && x.date===item.date && x.time===item.time && x.plant===item.plant && CONFLICT_PUMPS.includes(x.pump) && CONFLICT_PUMPS.includes(item.pump));
}

function loginView(){
 return `<main class="login"><section class="login-card">
  <div class="login-brand"><div class="logo-mark">B</div><h1>Betonexa</h1><p>Beton sevkiyat planlama demosu</p></div>
  <div class="notice">Demo sürümüdür. Veriler bu cihazın tarayıcısında saklanır.</div>
  <div class="login-users">${USERS.map(u=>`<button class="user-option" data-user="${esc(u)}"><span>${esc(u)}</span><span>→</span></button>`).join("")}</div>
 </section></main>`;
}

function filtered(){
 return state.shipments.filter(x=>{
  const hay=(x.company+" "+x.site+" "+x.contact+" "+x.phone+" "+x.className).toLowerCase();
  return (!state.filters.q||hay.includes(state.filters.q.toLowerCase())) &&
         (!state.filters.date||x.date===state.filters.date) &&
         (!state.filters.plant||x.plant===state.filters.plant) &&
         (!state.filters.pump||x.pump===state.filters.pump);
 }).sort((a,b)=>(a.date+a.time).localeCompare(b.date+b.time));
}

function appView(){
 const list=filtered();
 const today=new Date().toISOString().slice(0,10);
 const todayList=state.shipments.filter(x=>x.date===today);
 const totalM3=todayList.reduce((s,x)=>s+Number(x.amount||0),0);
 const conflicts=state.shipments.filter(isConflict).length;
 return `<div class="shell">
  <header class="topbar">
   <div class="brand"><div class="logo-mark">B</div><div><h1>Betonexa</h1><small>Concrete Dispatch Planning</small></div></div>
   <div class="top-actions"><button class="btn btn-light" id="newBtn">+ Yeni Sevkiyat</button><button class="btn btn-ghost mobile-only" id="newBtnMobile">+</button><button class="btn btn-ghost" id="logoutBtn">Çıkış</button></div>
  </header>
  <div class="grid">
   <aside class="sidebar">
    <div class="user-card"><strong>${esc(state.user)}</strong><span>Düzenleme yetkisi aktif</span></div>
    <button class="nav-btn active">📋 Sevkiyat Planı</button>
    <button class="nav-btn" id="exportBtn">⬇️ CSV Dışa Aktar</button>
    <button class="nav-btn" id="resetBtn">↺ Demo Verisini Sıfırla</button>
   </aside>
   <main class="content">
    <section class="stats">
      <div class="stat"><div class="value">${todayList.length}</div><div class="label">Bugünkü döküm</div></div>
      <div class="stat"><div class="value">${totalM3}</div><div class="label">Bugünkü toplam m³</div></div>
      <div class="stat"><div class="value">${new Set(todayList.map(x=>x.plant)).size}</div><div class="label">Aktif santral</div></div>
      <div class="stat"><div class="value">${conflicts}</div><div class="label">Pompa çakışması</div></div>
    </section>
    <section class="panel">
      <div class="panel-head"><h2>Sevkiyat Planı</h2><button class="btn btn-primary" id="newBtn2">+ Ekle</button></div>
      <div class="filters">
       <div class="field"><label>Arama</label><input id="qFilter" class="input" placeholder="Firma, şantiye, sorumlu..." value="${esc(state.filters.q)}"></div>
       <div class="field"><label>Tarih</label><input id="dateFilter" type="date" class="input" value="${esc(state.filters.date)}"></div>
       <div class="field"><label>Santral</label><select id="plantFilter" class="input"><option value="">Tümü</option>${PLANTS.map(x=>`<option ${state.filters.plant===x?"selected":""}>${x}</option>`).join("")}</select></div>
       <div class="field"><label>Pompa</label><select id="pumpFilter" class="input"><option value="">Tümü</option>${PUMPS.map(x=>`<option ${state.filters.pump===x?"selected":""}>${x}</option>`).join("")}</select></div>
      </div>
    </section>
    <section class="panel">
      <div class="table-wrap">
       ${list.length?`<table><thead><tr><th>Tarih / Saat</th><th>Santral</th><th>Firma / Şantiye</th><th>Beton</th><th>Miktar</th><th>Pompa</th><th>Sorumlu</th><th>Durum</th><th></th></tr></thead><tbody>
       ${list.map(x=>`<tr class="${isConflict(x)?"conflict":""}">
        <td><strong>${fmtDate(x.date)}</strong><br>${esc(x.time)}</td><td>${esc(x.plant)}</td>
        <td><strong>${esc(x.company)}</strong><br>${esc(x.site)}</td>
        <td>${esc(x.className)}<br><span class="badge info">${esc(x.slump||"")}</span> ${x.gross?'<span class="badge warn">Brüt</span>':""}</td>
        <td><strong>${esc(x.amount)} m³</strong></td><td>${esc(x.pump)}</td>
        <td>${esc(x.contact)}<br><small>${esc(x.phone)}</small></td>
        <td>${isConflict(x)?'<span class="badge warn">Çakışma</span>':'<span class="badge ok">Planlandı</span>'}</td>
        <td><div class="actions"><button class="icon-btn edit" data-id="${x.id}">✏️</button><button class="icon-btn delete" data-id="${x.id}">🗑️</button></div></td>
       </tr>`).join("")}</tbody></table>`:`<div class="empty">Filtreye uygun sevkiyat bulunamadı.</div>`}
      </div>
    </section>
   </main>
  </div>
 </div>`;
}

function formModal(item={}){
 const v=(k,d="")=>item[k]??d;
 return `<div class="modal-backdrop" id="modalBackdrop"><section class="modal">
  <div class="modal-head"><h3>${item.id?"Sevkiyatı Düzenle":"Yeni Sevkiyat"}</h3><button class="icon-btn" id="closeModal">✕</button></div>
  <form id="shipmentForm">
   <div class="modal-body"><div class="form-grid">
    <div class="field"><label>Tarih *</label><input required name="date" type="date" class="input" value="${esc(v("date",new Date().toISOString().slice(0,10)))}"></div>
    <div class="field"><label>Saat *</label><input required name="time" type="time" class="input" value="${esc(v("time","09:00"))}"></div>
    <div class="field"><label>Santral *</label><select required name="plant" class="input"><option value="">Seçiniz</option>${PLANTS.map(x=>`<option ${v("plant")===x?"selected":""}>${x}</option>`).join("")}</select></div>
    <div class="field"><label>Firma *</label><input required name="company" class="input" value="${esc(v("company"))}"></div>
    <div class="field wide"><label>Şantiye *</label><input required name="site" class="input" value="${esc(v("site"))}"></div>
    <div class="field"><label>Beton sınıfı *</label><input required name="className" class="input" placeholder="C30/37" value="${esc(v("className"))}"></div>
    <div class="field"><label>Miktar (m³) *</label><input required min="1" name="amount" type="number" class="input" value="${esc(v("amount"))}"></div>
    <div class="field"><label>Pompa *</label><select required name="pump" class="input">${PUMPS.map(x=>`<option ${v("pump","Pompasız")===x?"selected":""}>${x}</option>`).join("")}</select></div>
    <div class="field"><label>Kıvam</label><select name="slump" class="input">${["S3","S4"].map(x=>`<option ${v("slump","S3")===x?"selected":""}>${x}</option>`).join("")}</select></div>
    <div class="field"><label>Katkı</label><select name="additive" class="input">${["Standart","Katkısız"].map(x=>`<option ${v("additive","Standart")===x?"selected":""}>${x}</option>`).join("")}</select></div>
    <div class="field"><label>Sorumlu *</label><input required name="contact" class="input" value="${esc(v("contact"))}"></div>
    <div class="field"><label>Telefon *</label><input required name="phone" class="input" placeholder="05xx xxx xx xx" value="${esc(v("phone"))}"></div>
    <div class="field wide"><label><input name="gross" type="checkbox" ${v("gross")?"checked":""}> Brüt beton olarak işaretle</label></div>
    <div class="field wide"><label>Not</label><textarea name="note" rows="3" class="input">${esc(v("note"))}</textarea></div>
   </div></div>
   <div class="modal-foot"><button type="button" class="btn btn-ghost" id="cancelModal">Vazgeç</button><button class="btn btn-primary">Kaydet</button></div>
  </form>
 </section></div>`;
}

function render(){
 document.getElementById("app").innerHTML=state.user?appView():loginView();
 bind();
}

function openModal(id=null){
 state.editingId=id;
 const item=id?state.shipments.find(x=>x.id===id):{};
 document.body.insertAdjacentHTML("beforeend",formModal(item));
 document.getElementById("shipmentForm").addEventListener("submit",handleSubmit);
 document.getElementById("closeModal").onclick=closeModal;
 document.getElementById("cancelModal").onclick=closeModal;
 document.getElementById("modalBackdrop").onclick=e=>{if(e.target.id==="modalBackdrop")closeModal()}
}
function closeModal(){document.getElementById("modalBackdrop")?.remove();state.editingId=null}

function handleSubmit(e){
 e.preventDefault();
 const f=new FormData(e.target);
 const item={
  id:state.editingId||crypto.randomUUID(),
  date:f.get("date"),time:f.get("time"),plant:f.get("plant"),company:f.get("company"),site:f.get("site"),
  className:f.get("className"),amount:Number(f.get("amount")),pump:f.get("pump"),slump:f.get("slump"),
  additive:f.get("additive"),contact:f.get("contact"),phone:f.get("phone"),gross:f.get("gross")==="on",
  note:f.get("note"),createdBy:state.user
 };
 if(state.editingId) state.shipments=state.shipments.map(x=>x.id===state.editingId?item:x);
 else state.shipments.push(item);
 save();closeModal();render();toast(isConflict(item)?"Kaydedildi; pompa çakışması algılandı.":"Sevkiyat kaydedildi.");
}

function exportCSV(){
 const headers=["Tarih","Saat","Santral","Firma","Şantiye","Beton Sınıfı","Miktar m3","Pompa","Kıvam","Katkı","Brüt","Sorumlu","Telefon","Not"];
 const rows=state.shipments.map(x=>[x.date,x.time,x.plant,x.company,x.site,x.className,x.amount,x.pump,x.slump,x.additive,x.gross?"Evet":"Hayır",x.contact,x.phone,x.note]);
 const csv=[headers,...rows].map(r=>r.map(v=>`"${String(v??"").replaceAll('"','""')}"`).join(";")).join("\n");
 const blob=new Blob(["\ufeff"+csv],{type:"text/csv;charset=utf-8"});
 const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="betonexa-sevkiyat.csv";a.click();URL.revokeObjectURL(a.href);
}

function bind(){
 document.querySelectorAll("[data-user]").forEach(b=>b.onclick=()=>{state.user=b.dataset.user;localStorage.setItem("betonexa_user",state.user);render()});
 ["newBtn","newBtn2","newBtnMobile"].forEach(id=>{const el=document.getElementById(id);if(el)el.onclick=()=>openModal()});
 const logout=document.getElementById("logoutBtn");if(logout)logout.onclick=()=>{localStorage.removeItem("betonexa_user");state.user="";render()};
 document.querySelectorAll(".edit").forEach(b=>b.onclick=()=>openModal(b.dataset.id));
 document.querySelectorAll(".delete").forEach(b=>b.onclick=()=>{if(confirm("Bu sevkiyat silinsin mi?")){state.shipments=state.shipments.filter(x=>x.id!==b.dataset.id);save();render();toast("Sevkiyat silindi.")}});
 [["qFilter","q"],["dateFilter","date"],["plantFilter","plant"],["pumpFilter","pump"]].forEach(([id,key])=>{const el=document.getElementById(id);if(el)el.oninput=()=>{state.filters[key]=el.value;render()}});
 const ex=document.getElementById("exportBtn");if(ex)ex.onclick=exportCSV;
 const reset=document.getElementById("resetBtn");if(reset)reset.onclick=()=>{if(confirm("Demo verileri sıfırlansın mı?")){state.shipments=structuredClone(seed);save();render()}};
}
render();
