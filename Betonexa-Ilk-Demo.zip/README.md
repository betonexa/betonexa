# Betonexa Demo

Bu klasör, Vercel veya GitHub Pages üzerinde çalışabilecek ilk Betonexa mobil uyumlu demodur.

## İçerik
- Sevkiyat ekleme, düzenleme ve silme
- Tarih, santral ve metin filtresi
- Toplam sevkiyat ve m³ özeti
- 47'lik, 52'lik ve 56'lık pompalarda aynı tarih/saat/santral çakışma uyarısı
- Özlem Gülbay, Cem Ekici ve Ali Oğuz kullanıcı seçimi
- Veriler tarayıcıdaki localStorage alanında tutulur

## GitHub'a yükleme
1. ZIP dosyasını iPhone'un Dosyalar uygulamasında açın.
2. ZIP açılınca oluşan `betonexa-demo` klasörüne girin.
3. GitHub'daki `choose your files` seçeneğine dokunun.
4. `index.html`, `style.css`, `app.js` ve `README.md` dosyalarını seçin.
5. Alttaki yeşil `Commit changes` düğmesine dokunun.

## Önemli
Bu ilk demo, gerçek çok kullanıcılı bulut veritabanı içermez. Her cihaz kendi tarayıcısında ayrı veri saklar.
Gerçek ortak kullanım için sonraki aşamada Supabase/Firebase gibi bir veritabanı ve kullanıcı girişi eklenmelidir.
