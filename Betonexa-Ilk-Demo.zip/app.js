const plants=["Işıkkent","Torbalı","Gaziemir","Özbek","Çeşme","Çiğli","Koyundere","Aliağa","Zeytindağ","Akhisar","Aydın","Tekirdağ","Kıraç","Çorlu"];
const STORAGE_KEY="betonexa_shipments_v1";

const sample=[
 {id:crypto.randomUUID(),date:new Date().toISOString().slice(0,10),time:"09:00",plant:"Işıkkent",company:"Önerge Yapı",site:"Bornova Konut Projesi",concreteClass:"C30/37",quantity:90,pumpType:"Pompalı",pumpSize:"47'lik",consistency:"S4",additive:"Katkılı",responsible:"Mehmet Yılmaz",phone:"0532 000 00 00",note:"Giriş kapısı kuzey cephede.",updatedBy:"Özlem Gülbay"},
 {id:crypto.randomUUID(),date:new Date().toISOString().slice(0,10),time:"13:30",plant:"Gaziemir",company:"Ege İnşaat",site:"Havalimanı Depo Sahası",concreteClass:"C25/30",quantity:60,pumpType:"Pompasız",pumpSize:"",consistency:"S3",additive:"Katkısız",responsible:"Ayşe Demir",phone:"0542 111 11 11",note:"",updatedBy:"Cem Ekici"}
];

let shipments=load();
let editingId=null;

const $=id=>document.getElementById(id);
const dialog=$("shipmentDialog");
const form=$("shipmentForm");

function load(){
  const raw=localStorage.getItem(STORAGE_KEY);
  if(!raw){localStorage.setItem(STORAGE_KEY,JSON.stringify(sample)); return sample;}
  try{return JSON.parse(raw)}catch{return sample}
}
function save(){localStorage.setItem(STORAGE_KEY,JSON.stringify(shipments))}
function esc(v=""){return String(v).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
function fillPlants(){
  $("plant").innerHTML=plants.map(p=>`<option>${p}</option>`).join("");
  $("filterPlant").innerHTML='<option value="">Tümü</option>'+plants.map(p=>`<option>${p}</option>`).join("");
}
function formatDate(s){return new Intl.DateTimeFormat("tr-TR",{day:"2-digit",month:"long",year:"numeric",weekday:"long"}).format(new Date(s+"T12:00:00"))}
function filtered(){
  const d=$("filterDate").value,p=$("filterPlant").value,q=$("search").value.trim().toLocaleLowerCase("tr-TR");
  return shipments.filter(x=>(!d||x.date===d)&&(!p||x.plant===p)&&(!q||[x.company,x.site,x.responsible,x.concreteClass].join(" ").toLocaleLowerCase("tr-TR").includes(q)))
    .sort((a,b)=>(a.date+a.time).localeCompare(b.date+b.time));
}
function render(){
  const data=filtered(), list=$("shipmentList"); list.innerHTML="";
  $("emptyState").classList.toggle("hidden",data.length>0);
  data.forEach(x=>{
    const node=$("shipmentCardTemplate").content.cloneNode(true);
    node.querySelector(".time-pill").innerHTML=`${esc(x.time)}<div style="font-size:11px;font-weight:600;margin-top:3px">${esc(x.date.split("-").reverse().join("."))}</div>`;
    node.querySelector(".shipment-title").textContent=`${x.company} — ${x.site}`;
    node.querySelector(".plant-badge").textContent=x.plant;
    node.querySelector(".shipment-meta").textContent=`${x.concreteClass} • ${x.quantity} m³ • ${x.pumpType}`;
    const tags=[x.pumpSize,x.consistency,x.additive].filter(Boolean);
    node.querySelector(".shipment-tags").innerHTML=tags.map(t=>`<span class="tag">${esc(t)}</span>`).join("");
    node.querySelector(".shipment-contact").textContent=[x.responsible,x.phone].filter(Boolean).join(" • ");
    node.querySelector(".shipment-note").textContent=x.note?`Not: ${x.note}`:"";
    node.querySelector(".edit-btn").addEventListener("click",()=>openEdit(x.id));
    list.appendChild(node);
  });
  $("statCount").textContent=data.length;
  $("statM3").textContent=`${data.reduce((s,x)=>s+Number(x.quantity||0),0)} m³`;
  $("statPumped").textContent=data.filter(x=>x.pumpType==="Pompalı").length;
  renderConflicts(data);
}
function renderConflicts(data){
  const critical=["47'lik","52'lik","56'lık"], hits=[];
  for(let i=0;i<data.length;i++) for(let j=i+1;j<data.length;j++){
    const a=data[i],b=data[j];
    if(a.date===b.date && a.time===b.time && a.plant===b.plant && critical.includes(a.pumpSize) && a.pumpSize===b.pumpSize){
      hits.push(`${formatDate(a.date)} ${a.time} — ${a.plant} santralinde iki adet ${a.pumpSize} pompa çakışıyor.`);
    }
  }
  $("conflictBox").classList.toggle("hidden",hits.length===0);
  $("conflictBox").innerHTML=hits.length?`<strong>⚠️ Pompa çakışması</strong><br>${hits.map(esc).join("<br>")}`:"";
}
function openNew(){
  editingId=null; form.reset(); $("dialogTitle").textContent="Yeni Sevkiyat"; $("deleteBtn").classList.add("hidden");
  $("date").value=new Date().toISOString().slice(0,10); $("time").value="09:00"; $("pumpType").value="Pompalı";
  dialog.showModal();
}
function openEdit(id){
  const x=shipments.find(s=>s.id===id); if(!x)return;
  editingId=id; $("dialogTitle").textContent="Sevkiyatı Düzenle"; $("deleteBtn").classList.remove("hidden");
  Object.keys(x).forEach(k=>{const el=$(k); if(el)el.value=x[k]??""});
  dialog.showModal();
}
function close(){dialog.close()}
form.addEventListener("submit",e=>{
  e.preventDefault();
  const data={id:editingId||crypto.randomUUID(),date:$("date").value,time:$("time").value,plant:$("plant").value,company:$("company").value.trim(),site:$("site").value.trim(),concreteClass:$("concreteClass").value.trim(),quantity:Number($("quantity").value),pumpType:$("pumpType").value,pumpSize:$("pumpType").value==="Pompalı"?$("pumpSize").value:"",consistency:$("consistency").value,additive:$("additive").value,responsible:$("responsible").value.trim(),phone:$("phone").value.trim(),note:$("note").value.trim(),updatedBy:$("currentUser").value};
  if(editingId) shipments=shipments.map(x=>x.id===editingId?data:x); else shipments.push(data);
  save(); close(); render();
});
$("deleteBtn").addEventListener("click",()=>{if(editingId&&confirm("Bu sevkiyatı silmek istediğinize emin misiniz?")){shipments=shipments.filter(x=>x.id!==editingId);save();close();render()}});
$("addBtn").addEventListener("click",openNew);
$("closeDialog").addEventListener("click",close);
$("cancelBtn").addEventListener("click",close);
["filterDate","filterPlant","search"].forEach(id=>$(id).addEventListener("input",render));
$("clearFilters").addEventListener("click",()=>{$("filterDate").value="";$("filterPlant").value="";$("search").value="";render()});
$("pumpType").addEventListener("change",()=>{$("pumpSize").disabled=$("pumpType").value==="Pompasız";if($("pumpType").value==="Pompasız")$("pumpSize").value=""});
fillPlants(); render();
